#include<iostream>
using namespace std;
int main(){
    int N=7;
    cout<<"Multiplication table of 7"<<endl;
    for(int i=1;i<=10;i++){
        cout<<N<<"x"<<i<<"="<<N*i<<endl;
    }
    return 0;
}