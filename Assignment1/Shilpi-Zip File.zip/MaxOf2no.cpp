#include <iostream>
using namespace std;
int main()
{
    int a,b;
    cout<<"Enter first number: ";
    cin>>a;
    cout<<"Enter second number: ";
    cin>>b;
    if(a>b){
        cout<<"Maximum is: "<<a<<endl;
    }
    else{
        cout<<"Maximum is: "<<b<<endl;
        }
        return 0;
}